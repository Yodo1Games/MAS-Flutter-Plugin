// This class implements the banner Ad view
import Flutter
import UIKit
import Yodo1MasCore


class BannerAdView: NSObject, FlutterPlatformView {
    //private let bannerView : UADSBannerView
    private let uiView : UIView
    private let listener : BannerAdListener
    let bannerAdView = Yodo1MasBannerAdView()

    init(frame: CGRect, id: Int64, arguments: Any?, messenger: FlutterBinaryMessenger) {
        let args = arguments as! [String: Any]? ?? [:]

        let size = args[YodoAdsConstants.BANNER_SIZE] as? String ?? ""

        let channel =  FlutterMethodChannel(
            name: YodoAdsConstants.BANNER_AD_CHANNEL + "_" + id.description,  binaryMessenger:  messenger)
        listener = BannerAdListener(channel: channel)

        uiView = UIView(frame: frame)
        super.init()
        let bounds = UIScreen.main.bounds
        let  width = bounds.size.width
        let  height = bounds.size.height
        var centerpoint = CGPoint(x: (width/2), y: 0)
        let sizee = bannerAdView.intrinsicContentSize
        if(self.getBannerSize(BannerSize: size) == .banner || self.getBannerSize(BannerSize: size) == .largeBanner || self.getBannerSize(BannerSize: size) == .iabMediumRectangle )
        {
             centerpoint = CGPoint(x: (sizee.width/2), y: sizee.height)
        }
        else
        {
             centerpoint = CGPoint(x: (width/2), y: sizee.height)
        }
       
        uiView.center.x = centerpoint.x
        
        bannerAdView.setAdSize(self.getBannerSize(BannerSize: size))
        //bannerAdView.setAdSize(.iabMediumRectangle)
        bannerAdView.loadAd()
        //bannerAdView.delegate = listener
        bannerAdView.adDelegate = listener
        uiView.addSubview(bannerAdView)
        uiView.layoutIfNeeded()
        
        
        

       
        
    }

    func view() -> UIView {
        uiView
    }

    func getBannerSize(BannerSize : String) -> Yodo1MasBannerAdSize {
        switch BannerSize
                    {
                        case "Banner":
                            return .banner
                        case "AdaptiveBanner":
                            return .adaptiveBanner
                        case "LargeBanner":
                            return .largeBanner
                        case "SmartBanner":
                            return .smartBanner
                        case "IABMediumRectangle":
                            return .iabMediumRectangle
                        default:
            
                            return .banner
                    }
    }


}

