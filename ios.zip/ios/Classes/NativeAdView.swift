import Flutter
import UIKit
import Yodo1MasCore


class NativeAdView: NSObject, FlutterPlatformView {
    //private let nativeView : UADSNativeView
    private let uiView : UIView
    private let listener : NativeAdListener
    let nativeAdView = Yodo1MasNativeAdView()

    init(frame: CGRect, id: Int64, arguments: Any?, messenger: FlutterBinaryMessenger) {
        let args = arguments as! [String: Any]? ?? [:]


        let size = args[YodoAdsConstants.NATIVE_SIZE] as? String ?? ""




        let channel =  FlutterMethodChannel(
            name: YodoAdsConstants.NATIVE_AD_CHANNEL + "_" + id.description,  binaryMessenger:  messenger)
        listener = NativeAdListener(channel: channel)

        uiView = UIView(frame: frame)
        super.init()
        let bounds = UIScreen.main.bounds
        let  width = bounds.size.width
        let  height = bounds.size.height
        var centerpoint = CGPoint(x: (width/2), y: 0)
        let sizee = nativeAdView.intrinsicContentSize
        if(self.getNativeSize(NativeSize: size) == .native || self.getNativeSize(NativeSize: size) == .largeNative || self.getNativeSize(NativeSize: size) == .iabMediumRectangle )
        {
             centerpoint = CGPoint(x: (sizee.width/2), y: sizee.height)
        }
        else
        {
             centerpoint = CGPoint(x: (width/2), y: sizee.height)
        }

        uiView.center.x = centerpoint.x

        nativeAdView.setAdSize(self.getNativeSize(NativeSize: size))
        //nativeAdView.setAdSize(.iabMediumRectangle)
        nativeAdView.loadAd()
        //nativeAdView.delegate = listener
        nativeAdView.adDelegate = listener
        uiView.addSubview(nativeAdView)
        uiView.layoutIfNeeded()






    }

    func view() -> UIView {
        uiView
    }

    func getNativeSize(NativeSize : String) -> Yodo1MasNativeAdSize {
        switch NativeSize
                    {
                        case "Native":
                            return .native
                        case "AdaptiveNative":
                            return .adaptiveNative
                        case "LargeNative":
                            return .largeNative
                        case "SmartNative":
                            return .smartNative
                        case "IABMediumRectangle":
                            return .iabMediumRectangle
                        default:

                            return .native
                    }
    }


}

